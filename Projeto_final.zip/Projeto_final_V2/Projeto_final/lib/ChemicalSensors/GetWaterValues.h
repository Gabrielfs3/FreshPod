#ifndef GetWaterValues_h
#define GetWaterValues_h

class GetWaterValues
{

    public:
        void init();
        float get_ph();
        void get_all();
        float get_ec();
        float get_o2();
        int16_t readDO_inph(uint32_t voltage_mv, uint8_t temperature_c);
        float get_temperatureinwater();
    
    private:
        float voltage,phValue,temperature;
};

#endif