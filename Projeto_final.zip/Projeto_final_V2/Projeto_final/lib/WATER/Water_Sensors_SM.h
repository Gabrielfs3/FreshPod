#ifndef Water_Sensors_SM_h
#define Water_Sensors_SM_h

#include "WaterSensors.h"

void WATER_SENSORS_INIT();
int runSwitchCaseWater(int timeMs);
void WaterSensorsTasks();
int returnWaterSensorsState(int currentstate);
float getPH();
float getO2();
float getEC();
float getWL();
float gettemperature();
long int get_TS_ph();
long int get_TS_o2();
long int get_TS_ec();
long int get_TS_water_level();
float get_TS_temperature();

#endif
