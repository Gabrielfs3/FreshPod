#ifndef Alarmistic_SM_h
#define Alarmistic_SM_h


void InitAlarmistic();
int runSwitchCaseAlarmistic();
void AlarmisticTasks();
int returnAlarmisticState(int currentstate);
void MQTT_INIT_ALARMISTIC();


#endif
