#ifndef REAL_TIME_CONTROL_h
#define REAL_TIME_CONTROL_h



class Real_Time{

public:
    void Init(); //inicia a ligaçao 
    void Task(); 

};

#endif