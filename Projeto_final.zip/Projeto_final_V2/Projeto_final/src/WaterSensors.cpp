#include <Arduino.h>
#include <NTPClient.h>
#include <WiFiUdp.h>
#include "GetWaterValues.h"
#include "SensorEc.h"
#include "SensorO2.h"
#include "WaterSensors.h"
#include "EnvironmentSensors.h"
#include "HC_SR04_driver.h"
#include "DS18B20.h"

//sampling
#define water_sampling 1000 //1secS

static float o2, ph, ec, water_level, temp;
long int TimeStamp_o2;
long int TimeStamp_ph;
long int TimeStamp_ec;
long int TimeStamp_water_level;
long int TimeStamp_temp_;
int pinecho, pintrig;

//WiFiUDP ntpUDP;
//NTPClient timeClient(ntpUDP);

WaterSensors::WaterSensors(int pink, int ping)
{
    echo_Pin = pink;
    trig_Pin = ping;
    pinecho = echo_Pin;
    pintrig = trig_Pin;
}

//SensorPh sensorph;
SensorO2 sensoro2;
SensorEc sensorec;
//GetWaterValues WaterValues1;
DS18B20 ds18b203(18);
HC_SR04_driver sensorwl(pinecho,pintrig);

void WaterSensors::init()
{
    //sensorph.init();
   // sensoro2.init();
   // sensorec.init();
    sensorwl.Init();
    ds18b203.Init();
   // timeClient.update();
}

void WaterSensors::water_sensors_tasks() //Executa a task de sampling em sampling
{
    //WaterValues.init();
  //  ph = sensorph.get_ph();
  //  TimeStamp_ph = getTs_temp_water();
    //o2 = sensoro2.get_o2();
    // TimeStamp_o2 =getTs_temp_water();
  
    //ec = sensorec.get_ec();
    //TimeStamp_ec = getTs_temp_water();
    water_level = sensorwl.get_dist();
    //TimeStamp_water_level = getTs_temp_water();
   // temp = ds18b203.get_temperature();
    //TimeStamp_temp_ = getTs_temp_water();
}

float WaterSensors::return_ph()
{
    return ph;
}

float WaterSensors::return_o2()
{
    return o2;
}

float WaterSensors::return_ec()
{
    return ec;
}

float WaterSensors::return_temp()
{
    return temp;
}

float WaterSensors::return_water_level()
{
    return water_level;
}

long int WaterSensors::return_TS_ph()
{
    return TimeStamp_ph;
}

long int WaterSensors::return_TS_o2()
{
    return TimeStamp_o2;
}

long int WaterSensors::return_TS_ec()
{
    return TimeStamp_ec;
}

long int WaterSensors::return_TS_water_level()
{
    return TimeStamp_water_level;
}

long int WaterSensors::return_TS_temp()
{
    return TimeStamp_temp_;
}