#include <Arduino.h>
#include "GetWaterValues.h"
#include <DS18B20.h>
#include "DFRobot_PH.h"
#include "DFRobot_EC.h"

#include <EEPROM.h>
#include <Wire.h>
#include <SPI.h>
#include <DFRobot_ADS1115.h>

#define VREF 5000    //VREF (mv)
#define ADC_RES 1024 //ADC Resolution

#define CAL1_V (269) //mv
#define CAL1_T (17)   //℃

#define RES2 820.0
#define ECREF 200.0


DFRobot_EC ec1;
DFRobot_PH ph;
DFRobot_ADS1115 ads_1(&Wire);
DS18B20 ds18b20_1(32);

float voltage1,voltage2=0,voltage3=0,ecValue,o2Value,voltage3toML, _rawEC;

const uint16_t DO_Table_inph[41] = {
    14460, 14220, 13820, 13440, 13090, 12740, 12420, 12110, 11810, 11530,
    11260, 11010, 10770, 10530, 10300, 10080, 9860, 9660, 9460, 9270,
    9080, 8900, 8730, 8570, 8410, 8250, 8110, 7960, 7820, 7690,
    7560, 7430, 7300, 7180, 7070, 6950, 6840, 6730, 6630, 6530, 6410};



int16_t GetWaterValues::readDO_inph(uint32_t voltage_mv, uint8_t temperature_c)
{
  uint16_t V_saturation = (uint32_t)CAL1_V + (uint32_t)35 * temperature_c - (uint32_t)CAL1_T * 35;
  return (voltage_mv * DO_Table_inph[temperature_c] / V_saturation);
}


void GetWaterValues::init()
{
  ds18b20_1.Init();
  //ph.begin();
 // ph.begin();
  //ec1.begin();
  ads_1.setAddr_ADS1115(ADS1115_IIC_ADDRESS0);   // 0x48
 // ads_1.setGain(eGAIN_ONE);   // 2/3x gain
  ads_1.setGain(eGAIN_TWOTHIRDS);
  ads_1.setMode(eMODE_SINGLE);       // single-shot mode
  ads_1.setRate(eRATE_128);          // 128SPS (default)
  ads_1.setOSMode(eOSMODE_SINGLE);   // Set to start a single-conversion
  ads_1.init();
}

void GetWaterValues::get_all()
{
  static unsigned long timepoint = millis();
  if(millis()-timepoint>10000U)  //time interval: 1s
  {
    timepoint = millis();
    if (ads_1.checkADS1115())
    {
      voltage1 = float(ads_1.readVoltage(1));   // read the voltage(VOLTS)
      voltage2 = float(ads_1.readVoltage(2));
      voltage3 = float(ads_1.readVoltage(3));
    }
    Serial.println("Voltage1: ");
    Serial.print(voltage1);
     Serial.println("Voltage2: ");
     Serial.print(voltage2);
    Serial.println("Voltage3: ");
    Serial.print(voltage3);
    ds18b20_1.update_temperature();
    temperature = ds18b20_1.get_temperature();           // read your temperature sensor to execute temperature compensation
    Serial.println("Temperature in water:");
    Serial.print(temperature);
   }
}


float GetWaterValues::get_ec()
{
  //ecValue = ec1.readEC(voltage1,temperature);  // convert voltage to pH with temperature compensation
  _rawEC = 1000*voltage1/RES2/ECREF;
  ecValue = _rawEC / (1.0+0.0185*(temperature-25.0))+3;  //temperature compensation
  
   return ecValue;
}


float GetWaterValues::get_ph()
{
  phValue = ph.readPH(voltage2,temperature);  // convert voltage to pH with temperature compensation
  // phValue = voltage2/50.8;
   return phValue;
}


float GetWaterValues::get_o2()
{
  o2Value = readDO_inph(voltage3,temperature);  // convert voltage to pH with temperature compensation
  o2Value = o2Value/1000;
   return o2Value;
}


float GetWaterValues::get_temperatureinwater()
{
   return temperature;
}




