#include <Arduino.h>
#include <MQTT.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include "WifiEsp32.h"
#include <Telemetry_SM2.h>
#include "../lib/ChemicalSensors/SensorEc.h"
//#include "../lib/ChemicalSensors/SensorPh.h"
#include "../lib/ChemicalSensors/SensorO2.h"
#include "../lib/WATER/HC_SR04_driver.h"
#include "../lib/WATER/WaterSensors.h"
#include "../lib/WATER/Water_Sensors_SM.h"
#include <ArduinoJson.h>
//#include "Water_Sensors_SM.h"
#include "EnvironmentSensors_SM.h"
#include "PowerMeter_SM.h"


WiFiClient net2;
PubSubClient client2(net2);



bool RealControl=false;
bool RealControl_shut=false;
bool RealLEDs=false;
bool RealPump=false;
bool RealFans=false;

char RealLEDs_value;
char RealFans_value;
char RealPump_value;

  String jsontable;

enum class trafStatesMachine : int        //estados
{
  STAND_BY,     
  PUBLISH_DATA
};

//-----------[ Period ]-----------------
const int DataMsTelemetry = 1000;             //Apagar

const int DataMsTelemetry_Water = 10000;          // 1 sec timeout ---alterar
const int DataMsTelemetry_Environment = 10000;        // 10 segundos timeout---aletrar para 30
const int DataMsTelemetry_Power = 60000;              // 1 min timeout

String newjsonstring;

boolean data_sent;                      //transisitions
boolean timeout_water_sensor;
boolean timeout_Environment;
boolean timeout_Power_Meter;
boolean MQTT_INIT_NEEDED;

//---------[ Water]-----------
float Pub_ec1,Pub_O2,Pub_pH, Pub_WL, Pub_temp;
long int Pub_TS_ph, Pub_TS_o2, Pub_TS_ec, Pub_TS_WL, Pub_TS_temp;
const char* outTopicwater = "/water/sensor/measurement/PHO2CE";
char message_water_buffer[300];
int lastSwitchTimeWater  = 0;


//---------[ Power Meter]-----------
float Pub_Consumption;
long int Pub_TS_Consumption;
const char* outTopicPower ="/Power/sensor/measurement/Consumo";
char message_Power_buffer[150];
int lastSwitchTimePower  = 0;

//---------[ Environment]-----------
float Pub_Luminousity, Pub_Temperature, Pub_Humidity;
long int Pub_TS_Luminousity, Pub_TS_Temperature, Pub_TS_Humidity;
const char* outTopicEnvironment ="/Environment/sensor/measurement/LumiTempHumi";
char message_Environment_buffer[150];
int lastSwitchTimeEnvironment  = 0;


//--------[alarmistica]
const char* outTopicAlarm = "/Alarm";
char message_Alarm_buffer[2];




const char* broker = "192.168.43.28";
const char* lastWiFiState = "DISCONNECTED";

void Publish_Water()
{
      Pub_pH = getPH();
      Pub_TS_ph = get_ts_humidity();
      Pub_ec1 = getEC();
      Pub_TS_ec = get_ts_humidity();
      Pub_O2 = getO2();
      Pub_TS_o2 = get_ts_humidity();
      Pub_WL = 29 - getWL() ;
      Pub_TS_WL = get_ts_humidity();
      Pub_temp = gettemperature();
      Pub_TS_temp = get_ts_humidity();

        //sprintf(message_buffer,"{\"pH\":%f,\"o2\":%f,\"ce\":%f}", Pub_pH, Pub_O2, Pub_ec1);
        sprintf(message_water_buffer,"{\"pH\":{\"timestamp\":%ld,\"value\":%f},\"o2\":{\"timestamp\":%ld,\"value\":%f},\"ec\":{\"timestamp\":%ld,\"value\":%f},\"WL\":{\"timestamp\":%ld,\"value\":%f},\"Temperature\":{\"timestamp\":%ld,\"value\":%f}}", Pub_TS_ph, Pub_pH, Pub_TS_o2 , Pub_O2, Pub_TS_ec, Pub_ec1, Pub_TS_WL, Pub_WL, Pub_TS_temp, Pub_temp);
        client2.publish(outTopicwater,message_water_buffer);
}

void Publish_environment()
{
  Pub_Luminousity=0;
  Pub_TS_Luminousity=0;
  Pub_Temperature=getTemperature();
  Pub_TS_Temperature=get_ts_temperature();
  Pub_Humidity=getHumidity();
  Pub_TS_Humidity=get_ts_humidity();  

  sprintf(message_Environment_buffer,"{\"Lumi\":{\"timestamp\":%ld,\"value\":%f},\"Temp\":{\"timestamp\":%ld,\"value\":%f},\"Humi\":{\"timestamp\":%ld,\"value\":%f}}",Pub_TS_Luminousity,Pub_Luminousity, Pub_TS_Temperature,Pub_Temperature,Pub_TS_Humidity,Pub_Humidity);
  client2.publish(outTopicEnvironment,message_Environment_buffer);
}

void Publish_Consumption()
{
  Pub_Consumption=getConsumption();
  Pub_TS_Consumption=get_ts_consumption();

  sprintf(message_Environment_buffer,"{\"timestamp\":%ld,\"value\":%f}",Pub_TS_Consumption,Pub_Consumption);

  //sprintf(message_Environment_buffer,"{\"Consumo\":{\"timestamp\":%ld,\"value\":%f}", Pub_TS_Consumption,Pub_Consumption);
  client2.publish(outTopicPower,message_Environment_buffer);
}


/////////Conectar ao MQTT///////
void MQTT_INIT()
{
  //client.begin(broker, net);                          //broker mqtt
   client2.setServer(broker,1883);
   while(!client2.connected()) 
 {
  Serial.print("\nConnected to");
  Serial.println(broker);
  if(client2.connect("400"))
  {
    Serial.print("\nConnected to");
    Serial.println(broker);
  }else
  {
    Serial.println("\nTrying connect again");
    delay(5000);
  }
 }
  Serial.println("\nconnected to mqtt broker!");
  MQTT_INIT_NEEDED=0;
}


trafStatesMachine stateTelemetry = trafStatesMachine::STAND_BY;  //initial state

void runSwitchCaseTelemetry(int timeMsTelemetry,const char* WiFi_state)        //state machine
{

  if(lastWiFiState == "AP_CONNECTED" && WiFi_state == "INTERNET_CONNECTED")
  {
    MQTT_INIT();
  }

  if((timeout_water_sensor==1 || timeout_Environment==1 || timeout_Power_Meter==1) && (WiFi_state == "INTERNET_CONNECTED"))
  {
    stateTelemetry = trafStatesMachine::PUBLISH_DATA;
  }

  if(data_sent == 1 )
  {
    stateTelemetry = trafStatesMachine::STAND_BY;
  }


  //Serial.println(timeout_water_data);
  
  switch(stateTelemetry)
  {
    case trafStatesMachine::STAND_BY:             
    {
      // temos que fazer if aqui visto que pode ler qualquer um doos 3 tipos de sensores////////////

      //#################[ Telemetry_Water] ############################
      if(timeMsTelemetry - lastSwitchTimeWater >= DataMsTelemetry_Water)
      {
        lastSwitchTimeWater = timeMsTelemetry;
        timeout_water_sensor = 1;

        Serial.println("Standy By  Water Telemetry");
        data_sent = 0;
      }
    
      //#################[ Telemetry_Environment] ############################
      if(timeMsTelemetry - lastSwitchTimeEnvironment >= DataMsTelemetry_Environment)
        {
          lastSwitchTimeEnvironment = timeMsTelemetry;
          timeout_Environment = 1;

          Serial.println("Standy By Environment Telemetry");
          data_sent = 0;
        }    

      //#################[ Telemetry_Power_Meter] ############################
      if(timeMsTelemetry - lastSwitchTimePower >= DataMsTelemetry_Power)
        {
          lastSwitchTimePower = timeMsTelemetry;
          timeout_Power_Meter = 1;

          Serial.println("Standy By  Power Meter Telemetry");
          data_sent = 0;
        }

      if(lastWiFiState == "AP_CONNECTED" && WiFi_state == "INTERNET_CONNECTED")
      {
        MQTT_INIT();
      }
      break;
    }

    case trafStatesMachine::PUBLISH_DATA:
    {
      //deve de haver formas mais eficientes de implemnetar isto
       if(timeout_water_sensor==1) 
      {
        Publish_Water();
        timeout_water_sensor=0;
      }
      if(timeout_Environment==1 )
      {
        Publish_environment();
        timeout_Environment=0;
      }
      if(timeout_Power_Meter==1)
      {
        Publish_Consumption();
        timeout_Power_Meter=0;
      }
      
      data_sent = 1;       
      Serial.println("Publishing Data");
    }
  }

  lastWiFiState = WiFi_state;

}

void MQTT_TASKS(const char* WiFi_state)
{
  int timeMsTelemetry = millis();
  runSwitchCaseTelemetry(timeMsTelemetry,WiFi_state);

}



void callback1(char* topic, byte* payload, unsigned int length) {
  // convert payload to char
  
  char message[length + 1];
  for (int i = 0; i < length; i++) {
    message[i] = (char)payload[i];
  }
  message[length] = '\0';
  String strTopic = String((char*)topic);
  Serial.println(strTopic);
  if (strTopic == "/Actuadores/RealTime/Control/LEDs") {
      Serial.println("Control Leds");
      RealControl=true;
      RealControl_shut=true;
      RealLEDs=true;
      RealLEDs_value=message[0];
      Serial.println(message[0]);
      
    }

  else if (strTopic == "/Actuadores/RealTime/Control/Fans") {
      RealControl=true;
      RealControl_shut=true;
        RealFans=true;
        RealFans_value=message[0];
      Serial.println("Control Fans");
      
       
    } 

  else if (strTopic == "/Actuadores/RealTime/Control/Pump") {
      RealControl=true;
      RealControl_shut=true;
      RealPump=true;
      RealPump_value=message[0];
      Serial.println("Control Pump ");
      
  }
  else{
  // parse JSON payload
  StaticJsonDocument<512> jsonDoc;
  DeserializationError error = deserializeJson(jsonDoc, message);
  
  if (error) {
    Serial.print("deserializeJson() failed: ");
    Serial.println(error.c_str());
    return;
  }
 
  // print the topic and parsed JSON data
  Serial.print("Topic: ");
  Serial.println(topic);
  Serial.print("Message: ");
  jsontable="";
  serializeJson(jsonDoc, jsontable);
  Serial.println();
  }

}


void susbcribeControl()
{
    client2.subscribe("/Actuadores/Tabela/Control");
    client2.subscribe("/Actuadores/RealTime/Control/LEDs");
    client2.subscribe("/Actuadores/RealTime/Control/Fans");
    client2.subscribe("/Actuadores/RealTime/Control/Pump");
    client2.setBufferSize(512);
    client2.setCallback(callback1);
    
}


String returnnewtable()
{
   return jsontable;
}

String Controlloop() {
  client2.loop();
  String tablefrommqtt="";
  tablefrommqtt=returnnewtable();
  return tablefrommqtt;
}

void AlarmisticSend(int pp)
{
        sprintf(message_Alarm_buffer,"%d",pp);
        client2.publish(outTopicAlarm,message_Alarm_buffer);
}


bool returnRealControl(){
    if(RealControl==true){
      RealControl=false;
      return true;
    }
  return false;
}

bool returnRealControl_shut(){
    if(RealControl_shut==true){
      RealControl_shut=false;
      return true;
    }
  return false;
}


bool returnRealLEDs(){
    if(RealLEDs==true){
      RealLEDs=false;
       return true;
    }
    return false;
}

bool returnRealPump(){
    if(RealPump==true){
      RealPump=false;
      return true;
    }
    return false;
 
}

bool returnRealFans(){
    if(RealFans==true){
      RealFans=false;
      return true;
    }
  return false;
}

bool returnRealLEDs_value(){
 if(RealLEDs_value=='1')
 {
  return true;
 }
 return false;
}
bool returnRealPump_value(){
  if(RealPump_value=='1')
 {
  return true;
 }
 return false;
}
bool returnRealFans_value(){
  if(RealFans_value=='1')
 {
  return true;
 }
 return false;
}