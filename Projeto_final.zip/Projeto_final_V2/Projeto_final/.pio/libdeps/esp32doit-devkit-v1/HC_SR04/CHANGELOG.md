# Changelog



## [v1.0.1](https://github.com/bjoernboeckle/HC_SR04/tree/v1.0.1)
- Use all sensors as default for functions.
- Improved examples

## [v1.0.0](https://github.com/bjoernboeckle/HC_SR04/tree/v1.0.0)
Initial release